// Chart initialization
const ctx = document.getElementById('myChart').getContext('2d');
const chart = new Chart(ctx, {
  type: 'line',
  data: {
    // Placeholder data for initial chart display
    labels: [],
    datasets: [],
  },
  options: {
    legend: {
      display: true,
      position: 'bottom',
      labels: {
        fontColor: 'white',
        fontSize: 12,
        boxWidth: 12,
      },
    },
  },
});

// Initialize index and mode
let isAbsolute = true;
const ENTRIES_TO_DISPLAY = 12;
let currentIndex = 1; // Assuming the dataset starts from index 1
let isFirstTime = true;
const keySolidFuels = "Current price indices: Solid fuels";
const keyGas = "Current price indices: Gas ";
const keyElectricity = "Current price indices: Electricity ";
const keyLiquidFuels = "Current price indices: Liquid fuels";
const monthNames = ["January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"];

async function updateChart() {
  try {
    const response = await fetch('JsonforForcaster.json');
    const dataset = await response.json();

    if (isFirstTime) {
      currentIndex = dataset.length - ENTRIES_TO_DISPLAY - 1;
      isFirstTime = false;
    }

    const startIndex = Math.max(currentIndex - 1, 0);

    if (currentIndex + ENTRIES_TO_DISPLAY >= dataset.length) {
      currentIndex--;
      return;
    }


    // Use a slice to get the entries for the window
    const entriesToDisplay = dataset.slice(startIndex, startIndex + ENTRIES_TO_DISPLAY);

    const labels = entriesToDisplay.map(entry => {
      const year = entry['Year and dataset code row'];
      const month = entry['Month'];
      return `${month} ${year}`;
    });

    const datasets = Object.keys(entriesToDisplay[0])
      .filter(key => key !== 'Year and dataset code row' && key !== 'Month')
      .map(key => {
        return {
          label: key.split(":")[1].trim(),
          data: entriesToDisplay.map(entry => entry[key]),
          borderColor: getRandomColor(),
          fill: false,
        };
      });

    chart.data = { labels, datasets };
    chart.update();
  } catch (error) {
    console.error('Error fetching or parsing data:', error);
    displayError('Error fetching data. Please try again.');
  }
}



document.getElementById('forecast-section').addEventListener('wheel', handleWheel);

function handleWheel(event) {
  event.preventDefault(); // Prevent the default behavior of scrolling the entire page
  if(currentMode === 0){
    const delta = Math.sign(event.deltaY) * 0.1;
    currentIndex = Math.max(currentIndex - delta, 1);
  
    // Update the chart
    updateChart();
  }
  // Determine the direction of the scroll
}

// Function to scroll backward
function scrollBackward() {
  if (currentMode === 0) {
    currentIndex = Math.max(currentIndex - 1, 1);
    updateChart();
  }
}

// Function to scroll forward
function scrollForward() {
  if (currentMode === 0) {
    currentIndex = Math.max(currentIndex - (-1), 1);
    updateChart();
  }
}
let currentMode = 0;
function switchMode() {
  if (currentMode === 0) {
    forecastChart();
    currentMode = 1;
    document.getElementById("ModeText").innerHTML="Mode: Forecast";
  } else {
    updateChart();
    currentMode = 0;
    document.getElementById("ModeText").innerHTML="Mode: Historical";
  }
}

async function forecastChart() {
  try {
    const response = await fetch('JsonforForcaster.json');
    const dataset = await response.json();
    //Get previous 12 months data for forecast
    currentIndex = dataset.length - ENTRIES_TO_DISPLAY - 1;
    let last12MonthEnteries = dataset.slice(currentIndex, currentIndex + ENTRIES_TO_DISPLAY);
    let futureMapping = [];
    futureMapping[keySolidFuels] = {
      "Avg": getAverageDifference(last12MonthEnteries, keySolidFuels),
      "Next": last12MonthEnteries[last12MonthEnteries.length - 1][keySolidFuels] + getAverageDifference(last12MonthEnteries, keySolidFuels)
    };
    futureMapping[keyGas] = {
      "Avg": getAverageDifference(last12MonthEnteries, keyGas),
      "Next": last12MonthEnteries[last12MonthEnteries.length - 1][keyGas] + getAverageDifference(last12MonthEnteries, keyGas)
    };
    futureMapping[keyElectricity] = {
      "Avg": getAverageDifference(last12MonthEnteries, keyElectricity),
      "Next": last12MonthEnteries[last12MonthEnteries.length - 1][keyElectricity] + getAverageDifference(last12MonthEnteries, keyElectricity)
    };
    futureMapping[keyLiquidFuels] = {
      "Avg": getAverageDifference(last12MonthEnteries, keyLiquidFuels),
      "Next": last12MonthEnteries[last12MonthEnteries.length - 1][keyLiquidFuels] + getAverageDifference(last12MonthEnteries, keyLiquidFuels)
    };
    var currentMonth = last12MonthEnteries[last12MonthEnteries.length - 1]["Month"];
    var currentYear = last12MonthEnteries[last12MonthEnteries.length - 1]["Year and dataset code row"];
    var nextMonthIndex = monthNames.indexOf(currentMonth);
    let addYear = 0;
    const labels = last12MonthEnteries.map(entry => {
      const month = monthNames[nextMonthIndex];
      let year = currentYear + addYear;
      nextMonthIndex++;
      if (nextMonthIndex === 12) {
        nextMonthIndex = 0;
        addYear += 1;
      }
      return `${month} ${year}`;
    });
    const forecastData = last12MonthEnteries.map(entry => {
      const updatedEntry = { ...entry }; // Create a shallow copy of the original entry

      // Iterate through the keys of the entry
      Object.keys(updatedEntry).forEach(key => {
        // Check if the value is a number (float)
        if (key !== 'Year and dataset code row' && key !== 'Month') {
          updatedEntry[key] = futureMapping[key]["Next"]; // Increment the float value by 10
          futureMapping[key]["Next"] = futureMapping[key]["Next"] + futureMapping[key]["Avg"];
        }
      });

      return updatedEntry;
    });
    const datasets = Object.keys(forecastData[0])
      .filter(key => key !== 'Year and dataset code row' && key !== 'Month')
      .map(key => {
        return {
          label: key.split(":")[1].trim(),
          data: forecastData.map(entry => entry[key]),
          borderColor: getRandomColor(),
          fill: false,
        };
      });
    chart.data = { labels, datasets };
    chart.update();
  } catch (error) {
    console.error('Error fetching or parsing data:', error);
    displayError('Error fetching data. Please try again.');
  }
}

function getAverageDifference(data, key) {
  const differences = data.reduce((acc, obj, index, array) => {
    if (index > 0) {
      const current = obj[key];
      const previous = array[index - 1][key];
      acc.push(current - previous);
    }
    return acc;
  }, []);
  // Calculate the average of differences
  return differences.reduce((sum, diff) => sum + diff, 0) / differences.length;
}

// Initial chart update
updateChart();

// Helper function to generate random color
function getRandomColor() {
  const letters = '0123456789ABCDEF';
  let color = '#';
  for (let i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
}

// Helper function to display error message
function displayError(message) {
  const errorMessageContainer = document.getElementById('error-message');
  errorMessageContainer.innerText = message;
}



setTimeout(function() {
  // $('#welcome').attr('display','none');
  document.getElementById( 'welcomeScreen' ).style.display = 'none';
}, 3000);