// Character count update for the form
const messageInput = document.getElementById('message');
const charCount = document.getElementById('charCount');

if (messageInput && charCount) {
    messageInput.addEventListener('focus', function () {
        charCount.style.display = 'inline-block';
    });

    messageInput.addEventListener('input', function () {
        charCount.textContent = 500 - this.value.length;
    });

    messageInput.addEventListener('blur', function () {
        charCount.style.display = 'none';
    });
}


document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});


document.addEventListener('DOMContentLoaded', function() {
    const navToggle = document.getElementById('nav-toggle');
    const navMenu = document.querySelector('header nav ul');
    const navLinks = document.querySelectorAll('header nav ul li a');

    // Function to toggle the menu
    function toggleMenu() {
        if (navMenu) {
            navMenu.classList.toggle('active');
        }
    }

    // Event listener for the toggle button
    if (navToggle) {
        navToggle.addEventListener('click', toggleMenu);
    }

    // Event listeners for each nav link
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            // Close the menu when a link is clicked
            if (window.innerWidth <= 768) { // mobile breakpoint
                toggleMenu();
            }
        });
    });
})

// document.getElementById('converter-form').addEventListener('submit', function(e) {
//     e.preventDefault();
//     const sourceCurrency = document.getElementById('source-currency').value;
//     const destinationCurrency = document.getElementById('destination-currency').value.toLowerCase();
//     const amount = document.getElementById('amount').value;
//
//     fetch(`https://www.floatrates.com/daily/${sourceCurrency}.json`)
//         .then(response => response.json())
//         .then(data => {
//             console.log('data',data.destinationCurrency.rate);
//             const rate = data.destinationCurrency.rate;
//             const convertedAmount = (amount * rate).toFixed(2);
//             document.getElementById('result').innerText = `${amount} ${sourceCurrency} = ${convertedAmount} ${destinationCurrency}`;
//         })
//         .catch(error => {
//             console.error('Error fetching exchange rates:', error);
//             document.getElementById('result').innerText = 'Error fetching exchange rates.';
//         });
// });

document.addEventListener('DOMContentLoaded', function() {
document.getElementById('converter-form').addEventListener('submit', async function(e) {
    e.preventDefault();

    const sourceCurrency = document.getElementById('source-currency').value;
    const destinationCurrency = document.getElementById('destination-currency').value;
    const amount = parseFloat(document.getElementById('amount').value);

    try {
        const response = await fetch(`https://www.floatrates.com/daily/${sourceCurrency}.json`);
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const data = await response.json();
        const rate = data[destinationCurrency.toLowerCase()].rate;
        const time = new Date(data[destinationCurrency.toLowerCase()].date);
        const convertedAmount = (amount * rate).toFixed(2);
        const resultString = `Source currency: ${sourceCurrency} \n` +
            `Destination Currency: ${destinationCurrency} \n` +
            `Current Exchange Rate: 1 ${sourceCurrency} = ${rate} ${destinationCurrency} \n` +
            `Calculation Timestamp: ${time.toLocaleString('en-GB', { timeZone: 'GMT' })} \n` +
            `Amount of transaction: ${amount.toFixed(2)} ${sourceCurrency} = ${convertedAmount} ${destinationCurrency}`;

        document.getElementById('result').innerText = resultString;
    } catch (error) {
        console.error('Error fetching exchange rates:', error);
        document.getElementById('result').innerText = 'Error fetching exchange rates.';
    }
});

})

document.addEventListener('DOMContentLoaded', function() {
    fetch('https://www.floatrates.com/daily/USD.json')
    .then(response => response.json())
    .then(data => {
        // Get the select elements by class name
        const selects = document.getElementsByClassName('currencySelect');

        // Iterate through each select element
        Array.from(selects).forEach(select => {
            // Iterate through each currency and create an option
            for (const currencyCode in data) {
                const currency = data[currencyCode];
                const option = document.createElement('option');
                option.value = currencyCode;
                option.text = `${currency.name} (${currencyCode})`;
                select.appendChild(option);
            }
        });
    })
    .catch(error => console.error('Error fetching currency data:', error));
})

setTimeout(function() {
    // $('#welcome').attr('display','none');
    document.getElementById( 'welcomeScreen' ).style.display = 'none';
}, 3000);